
class Test(object):

    def __int__(self):
        print("__int__")

    def test(self):
        print("test")

