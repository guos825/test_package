guoshuai
==========

### Installation:

`pip install https://github.com/guos825/test_package`

or

`python setup.py install`

### Example:

```python
from guoshuai.test import Test


t = Test()
t.test()

```
